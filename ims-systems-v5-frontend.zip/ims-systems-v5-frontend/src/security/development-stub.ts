/**
 * Development-only frontend security stub (D-06).
 *
 * WARNING: Must never be enabled when NODE_ENV=production.
 * Transport-agnostic — does not establish production cookie/bearer transport (D-20).
 */

import type {
  AuthClient,
  ClientIdentity,
  GetAccessTokenOptions,
  LoginOptions,
  PasswordCredentials,
  RegisterCredentials,
  SwitchOrganisationInput,
} from "./auth-client";
import type { AuthzClient, ClientAuthorizationCheck } from "./authz-client";
import {
  clearActiveOrganisation,
  setActiveOrganisationContext,
} from "@/shared/lib/active-organisation";

/** Deterministic ObjectId-shaped organisation id for local/dev (D-09). */
export const DEV_STUB_ORGANIZATION_ID = "000000000000000000000001";

/**
 * Demo directory user used for My Profile until real auth maps subject → user.
 * Matches Ada Lovelace from `pnpm seed:demo` (session subject stays `dev-stub-user`).
 */
export const DEV_STUB_PROFILE_USER_ID = "100000000000000000000001";

export const DEV_STUB_IDENTITY: ClientIdentity = {
  subjectId: "dev-stub-user",
  email: "dev-stub@example.local",
  organizationId: DEV_STUB_ORGANIZATION_ID,
};

/**
 * Resolve which Users directory id to load for the current session profile.
 * ObjectId subjects use themselves; the development stub maps to the demo user.
 */
export function resolveProfileUserId(
  identity: ClientIdentity | null | undefined
): string | undefined {
  if (!identity?.subjectId) return undefined;
  if (/^[a-fA-F0-9]{24}$/.test(identity.subjectId)) return identity.subjectId;
  return DEV_STUB_PROFILE_USER_ID;
}

export class DevelopmentAuthClient implements AuthClient {
  async getIdentity(): Promise<ClientIdentity | null> {
    return DEV_STUB_IDENTITY;
  }

  async isAuthenticated(): Promise<boolean> {
    return true;
  }

  async getAccessToken(_options?: GetAccessTokenOptions): Promise<string | null> {
    void _options;
    return null;
  }

  async switchOrganisation(input: SwitchOrganisationInput): Promise<void> {
    setActiveOrganisationContext({
      organizationId: input.organizationId,
      auth0OrganizationId: input.auth0OrganizationId,
    });
  }

  async login(_options?: LoginOptions): Promise<void> {
    void _options;
    // Stub sessions are always authenticated.
  }

  async loginWithPassword(_credentials: PasswordCredentials): Promise<void> {
    void _credentials;
  }

  async register(_credentials: RegisterCredentials): Promise<void> {
    void _credentials;
  }

  async requestPasswordReset(_input: { email: string }): Promise<void> {
    void _input;
  }

  async logout(): Promise<void> {
    clearActiveOrganisation();
  }
}

export class DevelopmentAuthzClient implements AuthzClient {
  async allow(_check: ClientAuthorizationCheck): Promise<boolean> {
    void _check;
    return true;
  }
}

export function assertDevelopmentStubAllowed(nodeEnv: string | undefined): void {
  if (nodeEnv === "production") {
    throw new Error(
      "Development security stub must not be used when NODE_ENV=production"
    );
  }
}
