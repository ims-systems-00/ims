/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string;
  readonly VITE_SECURITY_PROVIDER?: string;
  readonly VITE_AUTH0_DOMAIN?: string;
  readonly VITE_AUTH0_CLIENT_ID?: string;
  readonly VITE_AUTH0_AUDIENCE?: string;
  readonly VITE_AUTH0_ORGANIZATION_ID?: string;
  /** OnlyOffice Document Server origin for DocsAPI (empty = Edit hidden). */
  readonly VITE_ONLYOFFICE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
